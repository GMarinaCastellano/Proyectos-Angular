export interface Tarea {
    nombre: string;
    prioridad: string;
    descripcion: string;
  }
  